#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#Converts the output of get_tweets_with_bearer_token.py into a TSV file

import pandas as pa
import re
from string import printable
import html
import os
import time

#Modify the JSON so that there is one tweet (instance) per line
def correct_output(input_file):
    with open(input_file, 'r', encoding="utf8") as f:
        output_file = input_file.replace(".json", "2.json")
        with open(output_file, 'w', encoding="utf8") as writer:
            next(f)
            for line in f:
                #Transform API output to get one object per line
                line = line.replace("[", "")
                line = line.replace("]", "")
                #Strip newline characters 
                line = line.replace("\n", "")
                #Remove commas after "}"
                #Note that this doesn't work for fields which are their own
                #arrays, such as geo information - but this can be easily fixed
                line = line.replace("},", "}\n")
                p = re.compile(r"Batch \d+, Code \d+")
                line = p.sub(r"\n", line)
                line = line.replace('"errors":', "\n")
                print(line, end="", file=writer)
                
#Fix tweets containing speech marks (turn double quotes into single quotes)
def further_correct_output(input_file):
    with open(input_file, 'r', encoding="utf8") as f:
        output_file = input_file.replace("2.json", "3.json")
        with open(output_file, 'w', encoding="utf8") as writer:
            for line in f:
                #If tweet text contains speech marks, change them to single quotes
                p = re.search(r'"text": "(.*)"        }', line)
                group = p.group(1) if p is not None else 'Not found'
                if (group != "Not found"):
                    #print(group)
                    group = group.replace('"',"'")
                    group = group.replace(r"\n", "")
                     #HAD TO ADD THESE LINES!
                    group = group.encode('unicode_escape').decode('ascii')
                    group = re.sub(r'\\u|\\U|\\x|\\X', '[unicode]', group)
                    #print(group)
                    #Delete text
                    p = re.compile(r'"text": "(.*)"        }')
                    line = p.sub(r'"text": "' + group + '"     }', line)     
                print(line, end="", file=writer)
    
#Extract relevant fields from JSON
def extract_info(input_file, output_file):
    with open(input_file, 'r', encoding="utf8") as f:          
        with open(output_file, 'w', encoding="utf8") as writer:
            #Add header to output file
            print("id\ttext\tconversation_id\tin_reply_to_user_id\tauthor_id\tcreated_at\tlang\tsource\terror", file=writer)
            for line in f:
                #Extract tweet ID
                p = re.search(r'"id": "(\d*)"', line)
                tweet_id = p.group(1)+"'" if p is not None else 'Unknown'
                #If there is no "id" property, use the "value" property instead (which is used for errors)
                if (tweet_id == 'Unknown'):
                    p = re.search(r'"value": "(\d*)"', line)
                    tweet_id = p.group(1)+"'" if p is not None else 'Unknown'
                    
                #Update the list of properties as required!
                #Should match properties in get_tweets_with_bearer_token.py
                properties = ["text","conversation_id","in_reply_to_user_id","author_id","created_at","lang","source","title"]
                data = []
                for prop in properties:
                    p = re.search(r'"' + prop + '": "(.*?)"', line)
                    datum = p.group(1) if p is not None else 'None'
                    data.append(datum)
                print(tweet_id + "\t" + "\t".join(data), file=writer) 

#Add derived metadata to the final dataframe
def supplement_data(file1, file2, file3, joinCol):
    #https://www.geeksforgeeks.org/how-to-do-a-vlookup-in-python-using-pandas/
    df1 = pa.read_csv(file1, sep="\t", dtype={'id': 'str'}) 
    df2 = pa.read_csv(file2, sep="\t", dtype={'id': 'str'}) 
    df3 = pa.merge(df1,df2,on=joinCol, how="outer")
    #Sort columns alphabetically
    #df3 = df3.reindex(columns=sorted(df3.columns))
    df3.to_csv(file3, sep="\t", index=False)

def remove_tmp_files():
    tmp_files = ["output2.json", "output3.json", "output3.csv"]
    for file in tmp_files:    
        try:
            os.remove(file)
        except OSError as e:
            print("Error: %s : %s" % (file, e.strerror))
    
correct_output("output.json")
further_correct_output("output2.json")
extract_info("output3.json", "output3.csv")
supplement_data("processed_corpus_v2_ids.csv", "output3.csv", "mlt_corpus_download_" + str(time.strftime("%Y%m%d-%H%M%S") + ".csv"), "id")
remove_tmp_files()

print("Done!")