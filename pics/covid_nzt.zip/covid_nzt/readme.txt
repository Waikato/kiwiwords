﻿================================================================================
The Covid NZ Twitter (CovidNZT) Corpus
================================================================================

The Covid NZ Twitter (CovidNZT) Corpus consists of 40,243 tweets obtained between 22 February and 10 November 2020. All tweets contain the hashtag #covid19nz, including variations with one or more capital letters. 

Tweets in the CovidNZT Corpus can be hydrated (downloaded from Twitter) using the code provided. The source code is adapted from Twitter's [sample code](https://github.com/twitterdev/Twitter-API-v2-sample-code) for API v2 endpoints.

Instructions for downloading the corpus are as follows:

- Apply for a [Twitter developer account](https://developer.twitter.com/en/apply-for-access) if you do not have one already.
- Ensure that [Python 3](https://www.python.org/downloads/) is installed on your machine. The code for hydrating the corpus uses `requests==2.24.0`, which in turn uses `requests-oauthlib==1.3.0`. You can install these packages as follows:
```
pip install requests
pip install requests-oauthlib
```
- Download and extract all files in the <a href="../pics/covid_nzt.zip">covid_nzt</a> folder. This folder contains a CSV file with only the tweet IDs, together with two Python scripts for downloading and formatting the data (namely, `get_tweets_with_bearer_token.py` and `json_to_tsv.py`).

- Configure your API bearer token by running the following command in the terminal:
```
export 'BEARER_TOKEN'='<your_bearer_token>'
```
- Run `get_tweets_with_bearer_token.py` from the terminal. 
```
python get_tweets_with_bearer_token.py > output.json
```
This will download the corpus in batches of 100 tweets. If you use the default settings, the script will take roughly **30 minutes** to run. The resulting file, `output.json`, is only pseudo-JSON (each batch is separated by a line in the form "Batch `X`, Code `Y`", where `X` and `Y` are numbers). Note that some tweets cannot be downloaded as they have been deleted from Twitter or belong to protected accounts.

- Run `json_to_tsv.py` to convert the output file to TSV format. 
```
python json_to_tsv.py
```
This script will produce a file called `CovidNZT_Tweets.csv`, which you can then open in a spreadsheet application. 
 
================================================================================
CITING THE CovidNZT CORPUS
================================================================================

If you use this corpus, please cite the following paper:

Burnette, J., & Calude, A. S. (2022). [Wake up New Zealand! Directives, politeness and stance in Twitter #Covid19NZ posts](https://www.sciencedirect.com/science/article/abs/pii/S0378216622001266). *Journal of Pragmatics*, 196, 6-23. doi: 10.1016/j.pragma.2022.05.002.