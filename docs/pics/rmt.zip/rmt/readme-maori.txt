# Putunga Reo Māori Tīhau: The Reo Māori Twitter Corpus

Ko te *Putunga Reo Māori Tīhau (RMT V2)* nei he putunga o ngā tīhau 94,163 kua tuhia ki te reo Māori. He mea hanga hei tautoko i ngā mahi reo Māori -ā-waha o te rorohiko, hei rauemi hoki mō ngā iwi Māori puta noa i te motu. E 2,302 ngā kaituhi pīhau reo Māori nei, ko ētehi he whaiaro nō te tangata ake, ko ētehi he mea tuku nō te kamupene. Kua tautohua ngā kaituhi pīhau nei e te pae tukutuku a [Indigenous Tweets](http://indigenoustweets.com/mi/) nā Prof. Kevin Scannell.

### Kia tikiake te putunga RMT
Nā tēneki waehere e taea ai te tikiake i ngā pīhau me ngā raraungameta. Kua hangaia te waehere nei mai i ngā waehere o Twitter arā te waehere tauira o API v2 endpoints.

Kia mōhio mai: kō ētehi o ngā tīhau kāore i reira ināianei, nō reira ka kore e taea te tikiake. **Tukua tētehi īmēra ki a [David Trye](mailto:dtrye@waikato.ac.nz) inā ka hiahiatia te katoa o te putunga RMT me ētehi raraungameta i tua atu, he raraungameta kua kōrerotia i tā mātou pepa.** 

Ka hāngai te tere o tāu tikiake ki tāu ake rate limit i tāu pūkete kaiwhanake o Twitter (arā, 300, 900 rānei ngā tono ki ia 15 meneti). Ki te whakapaua tāu tatau, ka puta mai te kōrero hē: 429 'Too many requests'.

- Tonoa tētehi [Pūkete Kaiwhanake o Twitter](https://developer.twitter.com/en/apply-for-access) inā kaore i a koe tētehi.
- Me matua noho a [Python 3](https://www.python.org/downloads/) ki tāu rorohiko. Ka whakamahia e te waehere tikiake i te `requests==2.24.0`, ā, ka whakamahia hoki te `requests-oauthlib==1.3.0`. Ka whēnei ngā tono hei utaina ēnei:
```
pip install requests
pip install requests-oauthlib
```
- Tikiake me te unu i ngā kōnae katoa i te kōpake <a href="../pics/rmt.zip">rmt</a>. Kei tēneki kōpaki tētehi kōnae ko `rmt-corpus-v2.csv` te ingoa, kei reira ngā tīhau IDs me ngā raraungameta. Kei reira hoki ngā waehere Python e rua mō te tikiake me te whakahōputu o ngā raraunga (arā, `get_tweets_with_bearer_token.py` me te `json_to_tsv.py`).
- Kia whakaritea ai tāu API bearer token me tuku atu tēnei tono:
```
export 'BEARER_TOKEN'='<your_bearer_token>'
```
- Whārere `get_tweets_with_bearer_token.py`.
```
python get_tweets_with_bearer_token.py > output.json
```
Nā reira, ka tikiake te 100 tīhau i ia tono, ā, nā ēnei whakaritenga ka āhua 45 meneti pea te roa. Ka whēnei te roa i te mea, ka 30,000 tīhau (300 tono x 100 tīhau) i ia 15 meneti. I te otinga ake ka rauikatia ki te kōnae output.json heoi anō he pseudo-JSON kē; ka motumotu ngā taupū ki tētehi rārangi e whēnei ana; "Batch X, Code Y", he nama te X me te Y.

- Whārere `json_to_tsv.py` kia whakawhiti ai te kōnae putunga ki te hōputu TSV.
```
python json_to_tsv.py
```

Ko te otinga o tēnei waehere ko te kōnae `rmt-corpus-final.csv`, he kōnae ka tūwheratia ki te tautono ripanga. Kua rite tahi te hōputu o ngā kōrero tīhau, arā ka tangohia ngā pūāhua motuhake, ka weteoro te HTML, ā, ka rite tahi te whakatakoto o ngā kōrero kaitīhau me ngā tūhononga. Ka tāpiritia hoki ngā raraungameta mai i te kōnae motuhake o `rmt-corpus-v2.csv`. Ki raro iho nei ka whakamārama atu ngā taurangi kei ngā kōnae CSV.

#### He Whakamārama Raraunga: rmt-corpus-v2.csv
Koia nei ngā māramatanga (inā e mōhio ana) kei te kōnae `rmt-corpus-v2.csv`, ahakoa kei a Twitter tonu te tīhau ake, kāore rānei.

| Taurangi                          | Whakamārama |
| -------------                     | ------------- |
| id                                | Te tautohu motuhake o Twitter mō tēnei tīhau. Ka taea te rapu tēnei tautohu ki [twitter.com/user/status/XXX](twitter.com/user/status/XXX), inā ko XXX te tīhau tautohu. |
| num_maori_words                   | E hia ngā kupu Māori ki te tīhau. |
| total_words                       | E hia te katoa o ngā kupu ki te tīhau. |
| percent_maori                     | Ko te paiheneti o ngā kupu Māori ki te tīha (=`num_maori_words` / `total_words`\*100).
| favourites                        | E hia ngā pānga (likes, retweets & quotes) i whakapā atu ki tēnei tīhau. |
| reply_count                       | E hia ngā whakahoki kōrero ki tēnei tīhau. |
| user.alias                        | He ingoakē mō kaitīhau, ka hangaia i te T`X`, inā ko te `X` tōna tūranga i tatau whānui o āna tīhau i te putunga katoa (`user.num_tweets`). |
| user.status                       | Te tūnga pūkete (i te Tīhema 2020) o te tangata nāna te tīhau i tuku: ka 'active', 'protected', 'suspended', 'not found' rānei. |
| user.followers                    | Tokohia āna apataki (i te Tīhema 2020). |
| user.friends                      | E hia ngā hoa ka whaia e ia (i te Tīhema 2020). |
| user.num_tweets                   | E hia ngā tīhau kua tukuna e ia. |
| user.region                       | Tōna wākāinga, e ai ki a ia. Inā i taea, i whakaritea ngā rohe nei ki  [New Zealand regions](https://en.wikipedia.org/wiki/Regions_of_New_Zealand) me ngā ingoa o ngā whenua ki tāwāhi. |
| year								| Te tau kua tukuna te tīhau (2007-2022).|

#### He Whakamārama Raraunga: rmt-corpus-final.csv
Ki te ora tonu te tīhau ki a Twitter, ka tāpiri atu hoki ngā taurangi ki raro iho nei. Ki te kore te taurangi e kitea ka tuhia ‘None’.

| Taurangi                          | Whakamārama |
| -------------                     | ------------- |
| content								| Ko ngā kōrero o te tīhau; kua rite tahi te hōputu o nga kōrero tīhau, arā ka tangohia ngā pūāhua motuhake, ka weteoro te HTML, ā, ka rite tahi te whakatakoto o ngā kōrero kaitīhau me ngā tūhononga. |
| conversation_id                   | Ko te tautohu motuhake mō te kōrerorero e noho atu ai tēnei tīhau. |
| in_reply_to_user_id               | Mehemea he whakahoki kōrero tēnei ki te tīhau o tāngata kē, koia nei te tautohu motuhake o te tangata nāna te tīhau tuatahi i tuku. | 
| author_id                         | Ko te tautohu motuhake o Twitter mō te kaituhi o te tīhau. |
| created_at                        | Te wā me te rā i tuku ai te tīhau, ka whēnei te hōputu: `YYYY-MM-DDTHH:mm:ss.000Z`.|
| lang                              | Ko te reo o te tīhau e ai ki a Twitter. Ka kore te reo Māori i kitea i kōnei i te mea he kore mōhio o te API ki te reo Māori. |
| source                            | Ko te pūrere, te tautono o wāho rānei i tuku i te tīhau (arā 'Twitter Web Client', 'Twitter for iPhone'). |
| error								| Ko te take i kore tikiake ai i te tīhau. Ki te hē mai, kā whēnei: 'Authorization Error', 'Not Found Error', 'None'.| 

#### He rauemi i tua atu
- Ko te waehere i whakarite ai i tātari ai te putunga RMT kei kōnei [project GitHub repository](https://github.com/Waikato/kiwiwords/tree/master/rmt_corpus).
- E taea ana te <a href="../pics/rmt-v1-wordlist.csv">tikiake kupu rārangi</a> me te tatau o ngā kupu me ngā tohuhaki i te putunga nei (V1).

#### Tohutoro te putunga RMT
Ki te whakamahi koe i te putunga RMT nei, tēnā koe me tohutoro whēnei mai:

- Trye, D., Keegan, T. T., Mato, P., & Apperley, M. (2022). [Harnessing Indigenous Tweets: The Reo Māori Twitter corpus](https://link.springer.com/article/10.1007/s10579-022-09580-w). <em>Lang Resources & Evaluation</em>, *56*, 1229-1268. doi:10.1007/s10579-022-09580-w

#### Kaimahi

- [David Trye](https://www.cs.waikato.ac.nz/~dgt12/)
- [Te Taka Keegan](https://www.cms.waikato.ac.nz/people/tetaka)
- [Paora Mato](https://www.waikato.ac.nz/php/research.php?mode=show&author=23169)
- [Mark Apperley](https://www.cms.waikato.ac.nz/people/mapperle)
- [Tamahau Brown](https://www.linkedin.com/in/tamahau-brown-9287b7139/)

Kaitautoko i tua:

- [Te Hiku Media](https://tehiku.nz/te-hiku-tech/), NZ
- [Kevin Scannell](https://cs.slu.edu/~scannell/index.html), Saint Louis University, US

#### Tautoko ā-pūtea
E mihi atu ana mō te tautoko ā-pūtea:

- Ngā Pae o te Māramatanga
- The University of Waikato

I whakatikahia te kōrero kei tēnei whārangi i Noema 2022. [Whakamōhio mai koa](mailto:dtrye@waikato.ac.nz) mehemea ka kite koe i ētehi hē i ngā waehere i tēneki whārangi rānei . 
- RMT V2: I te Noema 2022, 80,935 tīhau (**86%** o te putunga RMT V2) i taea ai te tikiake i a Twitter.
- RMT V1: I te Noema 2021, 72,575 tīhau (**92%** o te putunga RMT V1) i taea ai te tikiake i a Twitter.